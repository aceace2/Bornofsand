"use strict";
// Demir Arena — service worker: oyunu cihaza kaydeder, internetsiz açılmasını sağlar.
// Sayfa: önce ağ (yeni sürüm gelsin), 4 sn'de yanıt yoksa ya da çevrimdışıysa önbellek.
// Diğer dosyalar: önce önbellek.
const SURUM = "demir-arena-0.3.0-7a8c2db655";
const DOSYALAR = ["./", "./index.html", "./manifest.webmanifest", "./ikonlar/apple-touch-icon.png", "./ikonlar/ikon-192.png", "./ikonlar/ikon-512.png", "./ikonlar/ikon-64.png", "./ikonlar/ikon-maskeli-512.png"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(SURUM).then(c => c.addAll(DOSYALAR)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(adlar => Promise.all(adlar.filter(a => a.startsWith("demir-arena-") && a !== SURUM).map(a => caches.delete(a))))
    .then(() => self.clients.claim()));
});
function zamanAsimi(ms) { return new Promise((_, red) => setTimeout(() => red(new Error("zaman aşımı")), ms)); }
self.addEventListener("fetch", e => {
  const r = e.request;
  if (r.method !== "GET") return;
  const url = new URL(r.url);
  if (url.origin !== self.location.origin) return;
  if (r.mode === "navigate") {
    e.respondWith((async () => {
      const onbellek = await caches.open(SURUM);
      try {
        const yanit = await Promise.race([fetch(r), zamanAsimi(4000)]);
        if (yanit && yanit.ok) onbellek.put("./index.html", yanit.clone());
        return yanit;
      } catch (err) {
        return (await onbellek.match("./index.html")) || (await onbellek.match("./")) || Response.error();
      }
    })());
    return;
  }
  e.respondWith(caches.match(r).then(v => v || fetch(r).then(y => {
    if (y && y.ok) { const k = y.clone(); caches.open(SURUM).then(c => c.put(r, k)); }
    return y;
  })));
});
